//-----------------------------------------------------------------------
// <copyright file="TypeSelectorItemSettingsAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;
using UnityEngine;

namespace Sirenix.OdinInspector
{
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Interface)]
	public class TypeSelectorItemSettingsAttribute : Attribute
	{
		public string Name;
		public string CategoryPath;
		public SdfIconType Icon;
		public Color? LightIconColor;
		public Color? DarkIconColor;
		public int Priority;

		public TypeSelectorItemSettingsAttribute(string name = null,
															  string categoryPath = null,
															  SdfIconType icon = SdfIconType.None,
															  float lightIconColorR = 0.0f,
															  float lightIconColorG = 0.0f,
															  float lightIconColorB = 0.0f,
															  float lightIconColorA = 0.0f,
															  float darkIconColorR = 0.0f,
															  float darkIconColorG = 0.0f,
															  float darkIconColorB = 0.0f,
															  float darkIconColorA = 0.0f,
															  int priority = 0)
		{
			this.Name = name;
			this.CategoryPath = categoryPath;
			this.Icon = icon;

			if (lightIconColorR == 0.0f && lightIconColorG == 0.0f && lightIconColorB == 0.0f && lightIconColorA == 0.0f)
			{
				this.LightIconColor = null;
			}
			else
			{
				this.LightIconColor = new Color(lightIconColorR, lightIconColorG, lightIconColorB, lightIconColorA);
			}

			if (darkIconColorR == 0.0f && darkIconColorG == 0.0f && darkIconColorB == 0.0f && darkIconColorA == 0.0f)
			{
				this.DarkIconColor = null;
			}
			else
			{
				this.DarkIconColor = new Color(darkIconColorR, darkIconColorG, darkIconColorB, darkIconColorA);
			}
			
			this.Priority = priority;
		}
	}
}