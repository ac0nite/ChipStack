//-----------------------------------------------------------------------
// <copyright file="TypeSelectorDrawerSettingsAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;

namespace Sirenix.OdinInspector
{
	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class TypeSelectorDrawerSettingsAttribute : Attribute
	{
		public bool ShowNoneItem
		{
			get => this.showNoneItem ?? default;
			set => this.showNoneItem = value;
		}

		public bool ShowCategories
		{
			get => this.showCategories ?? default;
			set => this.showCategories = value;
		}

		public bool PreferNamespaces
		{
			get => this.preferNamespaces ?? default;
			set => this.preferNamespaces = value;
		}

		/// <summary>
		/// Function for filtering types displayed in the Type Selector.
		/// </summary>
		/// <example>
		/// <para>
		/// Resolver expects: any method that takes in a single parameter of <see cref="Type"/> and returns a <see cref="bool"/> describing if the type is included or not;
		/// exposes 'type' as a named value.
		/// </para>
		/// 
		/// <para>Implementation example: public bool SomeFilterMethod(Type type).</para>
		/// </example>
		public string FilterTypesFunction = null;

		public bool ShowNoneItemIsSet => this.showNoneItem.HasValue;
		public bool ShowCategoriesIsSet => this.showCategories.HasValue;
		public bool PreferNamespacesIsSet => this.preferNamespaces.HasValue;

		private bool? showNoneItem;
		private bool? showCategories;
		private bool? preferNamespaces;
	}
}