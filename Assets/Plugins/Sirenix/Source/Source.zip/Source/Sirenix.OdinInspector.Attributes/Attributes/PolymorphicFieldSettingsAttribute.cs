//-----------------------------------------------------------------------
// <copyright file="PolymorphicFieldSettingsAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
using System;

namespace Sirenix.OdinInspector
{
	public enum PickerHandleNonDefaultConstructors
	{
		ConstructIdeal,
		PreferUninitialized,
		LogWarning
	}
		
	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class PolymorphicFieldSettingsAttribute : Attribute
	{
		public bool ShowBaseType
		{
			get => this.showBaseType ?? default;
			set => this.showBaseType = value;
		}
		
		public bool LockOnNotNullReference = false;

		public PickerHandleNonDefaultConstructors HandleNonDefaultConstructors
		{
			get => this.handleNonDefaultConstructors ?? PickerHandleNonDefaultConstructors.ConstructIdeal;
			set => this.handleNonDefaultConstructors = value;
		}

		/// <summary>
		/// Function for creating an instance of the Type selected, overriding default behavior.
		/// </summary>
		/// <remarks>Does not override behavior on <see cref="UnityEngine.Object">Unity objects</see>.</remarks>
		/// <example>
		/// <para>
		/// Resolver expects: any method that takes in a single parameter of <see cref="Type"/> and returns an <see cref="object"/>;
		/// exposes 'type' as a named value.
		/// </para>
		/// 
		/// <para>Implementation example: public object Method(Type type).</para>
		/// </example>
		public string CreateInstanceFunction = null;

		/// <summary>
		/// Action for handling created/assigned instances.
		/// </summary>
		/// <remarks>Syncs with <c>ref</c> on parameters.</remarks>
		/// <example>
		/// <para>
		/// Resolver expects: any method that takes in a single parameter of the base type, and returns <see cref="System.Void"/>;
		/// exposes 'instance' as a named value.
		/// </para>
		/// 
		/// <para>Implementation example: public void Method(SomeBaseType instance).</para>
		/// </example>
		public string OnInstanceAssigned = null;
		
		public bool ShowBaseTypeIsSet => this.showBaseType.HasValue;
		public bool HandleNonDefaultConstructorsIsSet => this.handleNonDefaultConstructors.HasValue;

		private bool? showBaseType;
		private PickerHandleNonDefaultConstructors? handleNonDefaultConstructors;
	}
}