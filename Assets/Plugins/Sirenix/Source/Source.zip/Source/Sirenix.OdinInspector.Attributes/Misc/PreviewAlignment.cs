//-----------------------------------------------------------------------
// <copyright file="PreviewAlignment.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector
{
    public enum PreviewAlignment
    {
        Left,
        Right,
        Top,
        Bottom
    }
}