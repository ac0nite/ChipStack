//-----------------------------------------------------------------------
// <copyright file="TypeSelectorUserConfig.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using Sirenix.Serialization;
using Sirenix.Utilities;
using UnityEditor;
using UnityEngine;

namespace Sirenix.Config
{
#if false
	public class TestUserConfigWindow : OdinMenuEditorWindow
	{
		[MenuItem("Abc/Abc")]
		public static void BlaBla()
		{
			GetWindow<TestUserConfigWindow>();
		}

		protected override OdinMenuTree BuildMenuTree()
		{
			var tree = new OdinMenuTree(true)
			{
				{"General", TypeSelectorUserConfig.Instance},
			};

			tree.Config.SelectMenuItemsOnMouseDown = true;

			return tree;
		}
	}
#endif

	public class TypeSettings
	{
		public string Name;
		public string Category;
		public SdfIconType Icon;
		public Color? LightIconColor;
		public Color? DarkIconColor;

		public bool IsDefault(Type type) =>
			(string.IsNullOrEmpty(this.Name) || this.Name == type.Name) &&
			string.IsNullOrEmpty(this.Category) &&
			this.Icon == SdfIconType.None &&
			(!this.LightIconColor.HasValue || this.LightIconColor.Value.a == 0.0f) &&
			(!this.DarkIconColor.HasValue || this.DarkIconColor.Value.a == 0.0f);
	}

	[Serializable]
	[HideLabel]
	[InlineProperty]
	[HideReferenceObjectPicker]
	public abstract class StringSerializedCollection<T, TElement> where T : ICollection<TElement>, new()
	{
		[ShowInInspector]
		[NonSerialized]
		[LabelText("@$property.Parent.NiceName")]
		public T Collection = new T();

		[HideInInspector]
		[SerializeField]
		public List<string> serializedCollection = new List<string>();
	}

	[Serializable]
	[HideLabel]
	[InlineProperty]
	[HideReferenceObjectPicker]
	public class SerializedTypeSettingsDictionary : ISerializationCallbackReceiver
	{
		[Serializable]
		public class SerializedData
		{
			public string typeBound;
			public string displayName;
			public string category;
			public SdfIconType sdfIconType;
			public Color lightColor;
			public Color darkColor;
		}

		[ShowInInspector]
		[NonSerialized]
		[LabelText("@$property.Parent.NiceName")]
		public Dictionary<Type, TypeSettings> Dictionary = new Dictionary<Type, TypeSettings>();

		[HideInInspector]
		[SerializeField]
		public List<SerializedData> serializedDictionary = new List<SerializedData>();

		public void OnBeforeSerialize()
		{
			this.serializedDictionary.Clear();

			foreach (KeyValuePair<Type, TypeSettings> kvp in this.Dictionary)
			{
				TypeSettings data = kvp.Value;

				var serializedData = new SerializedData
				{
					typeBound = TwoWaySerializationBinder.Default.BindToName(kvp.Key),
					displayName = data.Name,
					category = data.Category,
					sdfIconType = data.Icon,
					lightColor = data.LightIconColor ?? Color.clear,
					darkColor = data.DarkIconColor ?? Color.clear
				};

				this.serializedDictionary.Add(serializedData);
			}
		}

		public void OnAfterDeserialize()
		{
			if (this.Dictionary.Count > 0)
			{
				return;
			}

			foreach (SerializedData serializedData in this.serializedDictionary)
			{
				Type type = TwoWaySerializationBinder.Default.BindToType(serializedData.typeBound);

				var data = new TypeSettings
				{
					Name = serializedData.displayName,
					Category = serializedData.category,
					Icon = serializedData.sdfIconType,
					LightIconColor = serializedData.lightColor != Color.clear ? serializedData.lightColor : (Color?) null,
					DarkIconColor = serializedData.darkColor != Color.clear ? serializedData.darkColor : (Color?) null,
				};

				this.Dictionary[type] = data;
			}
		}
	}

	[Serializable]
	[HideLabel]
	[InlineProperty]
	[HideReferenceObjectPicker]
	public class SerializedTypePriorityDictionary : ISerializationCallbackReceiver
	{
		[Serializable]
		public class SerializedData
		{
			public string typeName;
			public int priority;
		}

		[ShowInInspector]
		[NonSerialized]
		[LabelText("@$property.Parent.NiceName")]
		public Dictionary<Type, int> Dictionary = new Dictionary<Type, int>();

		[HideInInspector]
		[SerializeField]
		public List<SerializedData> serializedDictionary = new List<SerializedData>();

		public void OnBeforeSerialize()
		{
			this.serializedDictionary.Clear();

			foreach (KeyValuePair<Type, int> kvp in this.Dictionary)
			{
				var serializedData = new SerializedData
				{
					typeName = TwoWaySerializationBinder.Default.BindToName(kvp.Key),
					priority = kvp.Value
				};

				this.serializedDictionary.Add(serializedData);
			}
		}

		public void OnAfterDeserialize()
		{
			if (this.Dictionary.Count > 0)
			{
				return;
			}

			foreach (SerializedData serializedData in this.serializedDictionary)
			{
				Type type = TwoWaySerializationBinder.Default.BindToType(serializedData.typeName);

				int priority = serializedData.priority;

				this.Dictionary[type] = priority;
			}
		}
	}

	[Serializable]
	public abstract class SerializedTypeCollection<T> : StringSerializedCollection<T, Type>, ISerializationCallbackReceiver where T : ICollection<Type>, new()
	{
		public void OnBeforeSerialize()
		{
			this.serializedCollection.Clear();

			foreach (Type type in this.Collection)
			{
				this.serializedCollection.Add(TwoWaySerializationBinder.Default.BindToName(type));
			}
		}

		public void OnAfterDeserialize()
		{
			if (this.Collection.Count > 0)
			{
				return;
			}

			foreach (string s in this.serializedCollection)
			{
				this.Collection.Add(TwoWaySerializationBinder.Default.BindToType(s));
			}
		}
	}

	[Serializable]
	public class SerializedStringHashSet : StringSerializedCollection<HashSet<string>, string>, ISerializationCallbackReceiver
	{
		public void OnBeforeSerialize()
		{
			this.serializedCollection.Clear();

			foreach (string s in this.Collection)
			{
				this.serializedCollection.Add(s);
			}
		}

		public void OnAfterDeserialize()
		{
			if (this.Collection.Count > 0)
			{
				return;
			}

			foreach (string s in this.serializedCollection)
			{
				this.Collection.Add(s);
			}
		}
	}

	[Serializable]
	public class SerializedTypeHashSet : SerializedTypeCollection<HashSet<Type>> { }

	[Serializable]
	public class SerializedTypeList : SerializedTypeCollection<List<Type>> { }
	
	[SirenixEditorConfig]
	public class TypeSelectorUserConfig : GlobalConfig<TypeSelectorUserConfig>
	{
		public HashSet<Type> IllegalTypes => this.addedIllegalTypes.Collection;

		[SerializeField]
		private SerializedTypeHashSet shownTypes = new SerializedTypeHashSet();

		[SerializeField]
		private SerializedTypeHashSet hiddenTypes = new SerializedTypeHashSet();

		[SerializeField]
		private SerializedTypeHashSet addedIllegalTypes = new SerializedTypeHashSet();

		[SerializeField]
		private SerializedTypeHashSet removedIllegalTypes = new SerializedTypeHashSet();

		[SerializeField]
		private SerializedTypeSettingsDictionary typeSettings = new SerializedTypeSettingsDictionary();

		[SerializeField]
		private SerializedTypePriorityDictionary typePriorities = new SerializedTypePriorityDictionary();

		public void OpenEditor() => EditorWindow.GetWindow<TypeSelectorUserConfigWindow>();

		public void SetVisibility(Type type, bool isVisible)
		{
			bool isDefaultHidden = TypeRegistry.HiddenTypes.Contains(type);

			if (isDefaultHidden)
			{
				if (isVisible)
				{
					this.shownTypes.Collection.Add(type);
				}
				else
				{
					this.shownTypes.Collection.Remove(type);
				}
			}
			else
			{
				if (isVisible)
				{
					this.hiddenTypes.Collection.Remove(type);
				}
				else
				{
					this.hiddenTypes.Collection.Add(type);
				}
			}

			EditorUtility.SetDirty(this);
		}

		public bool IsVisible(Type type)
		{
			if (this.shownTypes.Collection.Contains(type))
			{
				return true;
			}

			return !TypeRegistry.HiddenTypes.Contains(type) && !this.hiddenTypes.Collection.Contains(type);
		}

		public bool IsIllegal(Type type) => this.addedIllegalTypes.Collection.Contains(type) ||
														(TypeRegistry.IllegalTypes.Contains(type) && !this.removedIllegalTypes.Collection.Contains(type));

		public void SetIllegal(Type type, bool value)
		{
			bool isDefaultIllegal = TypeRegistry.IllegalTypes.Contains(type);

			if (isDefaultIllegal)
			{
				if (value)
				{
					this.removedIllegalTypes.Collection.Remove(type);
				}
				else
				{
					this.removedIllegalTypes.Collection.Add(type);
				}
			}
			else
			{
				if (value)
				{
					this.addedIllegalTypes.Collection.Add(type);
				}
				else
				{
					this.addedIllegalTypes.Collection.Remove(type);
				}
			}
		}

		public TypeSettings TryGetSettings(Type type) => this.typeSettings.Dictionary.ContainsKey(type) ? this.typeSettings.Dictionary[type] : null;

		public int GetPriority(Type type) => this.typePriorities.Dictionary.ContainsKey(type) ? this.typePriorities.Dictionary[type] : 0;

		public bool IsModified(Type type)
		{
			return this.shownTypes.Collection.Contains(type) ||
					 this.hiddenTypes.Collection.Contains(type) ||
					 this.addedIllegalTypes.Collection.Contains(type) ||
					 this.removedIllegalTypes.Collection.Contains(type) ||
					 this.typePriorities.Dictionary.ContainsKey(type) ||
					 this.typeSettings.Dictionary.ContainsKey(type);
		}

		public void SetSettings(Type type, TypeSettings value) => this.typeSettings.Dictionary[type] = value;

		public void RemoveSettings(Type type) => this.typeSettings.Dictionary.Remove(type);

		public void HandleDefaultSettings(Type type, TypeSettings settings)
		{
			if (settings.IsDefault(type))
			{
				this.typeSettings.Dictionary.Remove(type);
			}
			else
			{
				if (string.IsNullOrEmpty(settings.Name))
				{
					settings.Name = type.Name;
				}

				if (settings.LightIconColor?.a == 0.0f)
				{
					settings.LightIconColor = null;
				}

				if (settings.DarkIconColor?.a == 0.0f)
				{
					settings.DarkIconColor = null;
				}
			}
		}


		public void SetPriority(Type type, int value)
		{
			if (value == 0)
			{
				this.typePriorities.Dictionary.Remove(type);
				return;
			}

			this.typePriorities.Dictionary[type] = value;
		}

		public void ResetType(Type type)
		{
			this.RemoveSettings(type);
			this.hiddenTypes.Collection.Remove(type);
			this.shownTypes.Collection.Remove(type);
			this.addedIllegalTypes.Collection.Remove(type);
			this.removedIllegalTypes.Collection.Remove(type);
			this.typePriorities.Dictionary.Remove(type);
		}
	}
}
#endif