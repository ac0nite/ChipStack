//-----------------------------------------------------------------------
// <copyright file="NullableReferenceDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define IF_OLD_NULLABLE_REF_EXISTS

using System;
using System.Collections;
using Sirenix.OdinInspector.Editor.Internal;
using Sirenix.Reflection.Editor;
using Sirenix.Utilities;
using Sirenix.Utilities.Editor;
using UnityEditor;
using UnityEngine;

// NOTE: this using statement is important for later Unity versions
using SerializationUtility = Sirenix.Serialization.SerializationUtility;

namespace Sirenix.OdinInspector.Editor.Drawers
{
	[AllowGUIEnabledForReadonly]
	[DrawerPriority(0, 0, 2000)]
	public sealed class NullableReferenceDrawer<T> : OdinValueDrawer<T>, IDefinesGenericMenuItems
	{
		private HybridObjectPicker ObjectPicker => HybridObjectPicker.Get(this.Property,
																								this.ValueEntry.BaseValueType,
																								this.selectorSettings,
																								this.polymorphicSettings,
																								this.Property);

		private bool ShowBaseType => this.polymorphicSettings?.ShowBaseType ?? true;
		private bool LockOnNotNullReference => this.polymorphicSettings?.LockOnNotNullReference ?? false;

		private bool shouldDrawReferencePicker;
		private bool allowSceneObjects;
		private bool drawChildren;
		private bool isValueUnityType;

		private SearchField searchField;
		private PropertySearchFilter searchFilter;

		private InlinePropertyAttribute inlineAttribute;
		private TypeSelectorDrawerSettingsAttribute selectorSettings;
		private PolymorphicFieldSettingsAttribute polymorphicSettings;
		
		private OdinDrawer[] bakedDrawerArray;

		protected override void Initialize()
		{
			if (GeneralDrawerConfig.Instance.useOldPolymorphicField)
			{
				this.SkipWhenDrawing = true;
				return;
			}

			this.bakedDrawerArray = this.Property.GetActiveDrawerChain().BakedDrawerArray;

			var searchableAttribute = this.Property.GetAttribute<SearchableAttribute>();

			if (searchableAttribute != null)
			{
				this.searchFilter = new PropertySearchFilter(this.Property, searchableAttribute);
				this.searchField = new SearchField();
			}

			this.allowSceneObjects = this.Property.GetAttribute<AssetsOnlyAttribute>() == null;
			this.isValueUnityType = typeof(UnityEngine.Object).IsAssignableFrom(this.ValueEntry.TypeOfValue);

			this.inlineAttribute = this.Property.Attributes.GetAttribute<InlinePropertyAttribute>();
			this.selectorSettings = this.Property.GetAttribute<TypeSelectorDrawerSettingsAttribute>();
			this.polymorphicSettings = this.Property.GetAttribute<PolymorphicFieldSettingsAttribute>();
		}

		public void PopulateGenericMenu(InspectorProperty property, GenericMenu genericMenu)
		{
			var entry = property.ValueEntry as IPropertyValueEntry<T>;

			bool isChangeable = property.ValueEntry.SerializationBackend.SupportsPolymorphism
									  && !entry.BaseValueType.IsValueType
									  && entry.BaseValueType != typeof(string);

			if (!isChangeable)
			{
				return;
			}

			if (entry.IsEditable) //&& entry.Property.GetAttribute<InlineEditorAttribute>() == null)
			{
				Rect rect = entry.Property.LastDrawnValueRect;
				rect.position = GUIUtility.GUIToScreenPoint(rect.position);
				rect.height = 20;

				genericMenu.AddItem(new GUIContent("Change Type"), false,
										  () => { this.ObjectPicker.Show(this.ValueEntry.WeakSmartValue, this.allowSceneObjects, rect); });
			}
			else

			{
				genericMenu.AddDisabledItem(new GUIContent("Change Type"));
			}
		}

		protected override void DrawPropertyLayout(GUIContent label)
		{
			if (this.ValueEntry.ValueState == PropertyValueState.ReferenceValueConflict)
			{
				this.CallNextDrawer(label);
			}
			
			if (Event.current.type == EventType.Layout)
			{
				this.shouldDrawReferencePicker = ShouldDrawReferenceObjectPicker(this.ValueEntry);

				this.drawChildren = this.Property.Children.Count > 0;

				if (this.Property.Children.Count > 0)
				{
					this.drawChildren = true;
				}
				else if (this.ValueEntry.ValueState != PropertyValueState.None)
				{
					this.drawChildren = false;
				}
				else
				{
					// NOTE: handling weird edge case from the old NullableReferenceDrawer

#if IF_OLD_NULLABLE_REF_EXISTS
#if SIRENIX_INTERNAL
					// NOTE: this is here, so that if the old drawer gets removed, we'll know about it.
					if (typeof(OldNullableReferenceDrawer<T>) == null)
					{
						// NOTE: if this if-statement is true: remove IF_OLD_NULLABLE_REF_EXISTS preprocessor
					}
#endif
					this.drawChildren = this.bakedDrawerArray[this.bakedDrawerArray.Length - 3] != this;
#else
					this.drawChildren = this.bakedDrawerArray[this.bakedDrawerArray.Length - 2] != this;
#endif
				}
			}

			if (this.ValueEntry.ValueState == PropertyValueState.NullReference)
			{
				if (this.isValueUnityType)
				{
					this.CallNextDrawer(label);
				}
				else
				{
					if (!this.ValueEntry.SerializationBackend.SupportsPolymorphism && this.ValueEntry.IsEditable)
					{
						SirenixEditorGUI.ErrorMessageBox("Unity-backed value is null. This should already be fixed by the FixUnityNullDrawer!" +
																	" It is likely that this type has been incorrectly guessed by Odin to be serialized by Unity when it is actually not." +
																	" Please create an issue on Odin's issue tracker stating how to reproduce this error message.");
					}

					this.DrawField(label);
				}
			}
			else
			{
				if (this.shouldDrawReferencePicker)
				{
					this.DrawField(label);
				}
				else
				{
					this.ObjectPicker.CheckForUpdates();

					if (this.ObjectPicker.IsReadyToClaim)
					{
						this.ChangeValue(this.ObjectPicker.Claim());
					}

					this.CallNextDrawer(label);
				}
			}
		}

		private void DrawReferencePicker(Rect position, int? foldoutId)
		{
			int controlId = foldoutId ?? GUIUtility.GetControlID(FocusType.Keyboard);

			bool lastMixedValue = EditorGUI.showMixedValue;

			if (this.ValueEntry.ValueState == PropertyValueState.ReferenceValueConflict)
			{
				EditorGUI.showMixedValue = true;
			}

			EditorGUI.BeginChangeCheck();
			object value = PolymorphicFieldHandler_WILL_BE_DEPRECATED.Field(this.Property,
																								 controlId,
																								 position,
																								 this.ValueEntry.WeakSmartValue,
																								 this.ValueEntry.BaseValueType,
																								 this.allowSceneObjects,
																								 false,
																								 this.selectorSettings,
																								 this.polymorphicSettings,
																								 this.Property);

			if (EditorGUI.EndChangeCheck())
			{
				this.ChangeValue(value);
			}

			EditorGUI.showMixedValue = lastMixedValue;

		}

		private void DrawField(GUIContent label)
		{
			if (this.inlineAttribute != null)
			{
				this.DrawFieldInline(label);
				return;
			}

			int? foldoutId = null;

			bool hasLabel = label != null && !string.IsNullOrEmpty(label.text);

			Rect valueRect = EditorGUILayout.GetControlRect(hasLabel);

			if (hasLabel)
			{
				Rect labelRect = valueRect.TakeFromLeft(EditorGUIUtility.labelWidth + 2.0f);

				this.DrawSearchFilter(labelRect.AlignRight(labelRect.width - EditorStyles.label.CalcWidth(label)));

				if (this.drawChildren)
				{
					this.Property.State.Expanded = EditorGUI.Foldout(labelRect, this.Property.State.Expanded, label, true);
					foldoutId = EditorGUIUtility_Internals.LastControlID;
				}
				else
				{
					labelRect = EditorGUI.IndentedRect(labelRect);

					GUI.Label(labelRect, label);
				}
			}
			else if (this.drawChildren)
			{
				if (EditorGUIUtility.hierarchyMode)
				{
					this.Property.State.Expanded = EditorGUI.Foldout(valueRect, this.Property.State.Expanded, GUIContent.none, false);
				}
				else
				{
					this.Property.State.Expanded = SirenixEditorGUI.Foldout(valueRect.TakeFromLeft(16.0f), this.Property.State.Expanded, GUIContent.none);
				}
			}

			this.DrawReferencePicker(valueRect, foldoutId);

			if (this.drawChildren)
			{
				bool toggle = this.ValueEntry.ValueState != PropertyValueState.NullReference && this.Property.State.Expanded;

				if (SirenixEditorGUI.BeginFadeGroup(this, toggle))
				{
					if (hasLabel)
					{
						if (this.searchFilter != null && this.searchFilter.HasSearchResults)
						{
							this.searchFilter.DrawSearchResults();
						}
						else
						{
							EditorGUI.indentLevel++;
							this.CallNextDrawer(null);
							EditorGUI.indentLevel--;
						}
					}
					else
					{
						this.CallNextDrawer(null);
					}
				}

				SirenixEditorGUI.EndFadeGroup();
			}
		}

		private void DrawFieldInline(GUIContent label)
		{
			bool shouldPushLabelWidth = this.inlineAttribute.LabelWidth > 0;

			if (label == null || label == GUIContent.none)
			{
				if (shouldPushLabelWidth)
				{
					GUIHelper.PushLabelWidth(this.inlineAttribute.LabelWidth);
				}

				this.DrawReferencePicker(GUILayoutUtility.GetRect(0, EditorGUIUtility.singleLineHeight), null);

				if (this.drawChildren)
				{
					this.CallNextDrawer(null);
				}

				if (shouldPushLabelWidth)
				{
					GUIHelper.PopLabelWidth();
				}

				return;
			}

			SirenixEditorGUI.BeginVerticalPropertyLayout(label);
			{
				if (shouldPushLabelWidth)
				{
					GUIHelper.PushLabelWidth(this.inlineAttribute.LabelWidth);
				}

				this.DrawReferencePicker(GUILayoutUtility.GetRect(0, EditorGUIUtility.singleLineHeight), null);

				if (this.drawChildren)
				{
					this.CallNextDrawer(null);
				}

				if (shouldPushLabelWidth)
				{
					GUIHelper.PopLabelWidth();
				}

				GUILayout.Space(UnityVersion.IsVersionOrGreater(2019, 3) ? 5 : 4);
			}
			SirenixEditorGUI.EndVerticalPropertyLayout();
		}

		private void DrawSearchFilter(Rect searchRect)
		{
			if (this.searchFilter == null)
			{
				return;
			}

			searchRect = searchRect.Padding(2, 0);

			if (searchRect.width < 16)
			{
				GUI.Label(searchRect, "...");
				return;
			}

			string newTerm = this.searchField.Draw(searchRect, this.searchFilter.SearchTerm, "Search for property...");

			if (newTerm == this.searchFilter.SearchTerm)
			{
				return;
			}

			this.searchFilter.SearchTerm = newTerm;

			this.Property.Tree.DelayActionUntilRepaint(() =>
			{
				if (!string.IsNullOrEmpty(newTerm))
				{
					this.Property.State.Expanded = true;
				}

				this.searchFilter.UpdateSearch();
				GUIHelper.RequestRepaint();
			});
		}

		private void ChangeValue(object newValue)
		{
			this.ValueEntry.Property.Tree.DelayActionUntilRepaint(() =>
			{
				this.ValueEntry.WeakValues[0] = newValue;

				if (newValue == null)
				{
					for (var i = 1; i < this.ValueEntry.ValueCount; i++)
					{
						this.ValueEntry.WeakValues[i] = null;
					}
				}
				else if (newValue is UnityEngine.Object)
				{
					for (var i = 1; i < this.ValueEntry.ValueCount; i++)
					{
						this.ValueEntry.WeakValues[i] = newValue;
					}
				}
				else
				{
					for (var i = 1; i < this.ValueEntry.ValueCount; i++)
					{
						this.ValueEntry.WeakValues[i] = SerializationUtility.CreateCopy(newValue);
					}
				}
			});
		}

		/// <summary>
		/// Returns a value that indicates if this drawer can be used for the given property.
		/// </summary>
		protected override bool CanDrawValueProperty(InspectorProperty property)
		{
			if (property.IsTreeRoot)
			{
				return false;
			}

			Type type = property.ValueEntry.BaseValueType;

			return (type.IsClass || type.IsInterface) && type != typeof(string) && !typeof(UnityEngine.Object).IsAssignableFrom(type);
		}
		  
		private static bool ShouldDrawReferenceObjectPicker(IPropertyValueEntry<T> entry)
		{
			return entry.SerializationBackend.SupportsPolymorphism
					 && !entry.BaseValueType.IsValueType
					 && entry.BaseValueType != typeof(string)
					 && !(entry.Property.ChildResolver is ICollectionResolver)
					 && !entry.BaseValueType.IsArray
					 && entry.IsEditable
					 && !entry.BaseValueType.InheritsFrom(typeof(IDictionary))
					 && !(entry.WeakSmartValue as UnityEngine.Object)
					 && entry.Property.GetAttribute<HideReferenceObjectPickerAttribute>() == null;
		}
	}
}
#endif